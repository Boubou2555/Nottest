import bear from "./bear.png";
import coin from "./coin.png";
import highVoltage from "./high-voltage.png";
import notcoin from "./notcoin.png";
import rocket from "./rocket.png";
import trophy from "./trophy.png";

export {
    bear,
    coin,
    highVoltage,
    notcoin,
    rocket,
    trophy
}
